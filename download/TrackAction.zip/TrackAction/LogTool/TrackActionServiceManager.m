//
//  TrackActionServiceManager.m
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import "TrackActionServiceManager.h"
#import <AdSupport/AdSupport.h>


@interface TrackActionServiceManager ()

@property (nonatomic,assign) NSTimeInterval timeOffset;


@end
@implementation TrackActionServiceManager

+ (instancetype)sharedManager
{
    static TrackActionServiceManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^
                  {
                      manager = [[self alloc] init];
                      manager.requestSerializer = [AFJSONRequestSerializer serializer];
                      AFJSONResponseSerializer *serialize = [AFJSONResponseSerializer serializer];
                      serialize.removesKeysWithNullValues = YES;
                      manager.responseSerializer = serialize;
                      manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html",@"text/json",@"text/javascript",@"image/jpeg", nil];
                      // 设置超时时间 30秒
                      manager.requestSerializer.timeoutInterval = 30.f;
                      manager.responseSerializer = serialize;
                      manager.deviceToken = @"";

                  });

    return manager;
}


-(void)setDeviceToken:(NSString *)deviceToken{

    deviceToken = [deviceToken stringByReplacingOccurrencesOfString:@"<"withString:@""];
    deviceToken = [deviceToken stringByReplacingOccurrencesOfString:@">"withString:@""];
    deviceToken = [deviceToken stringByReplacingOccurrencesOfString:@" "withString:@""];

    _deviceToken = deviceToken;
}



+ (NSURLSessionDataTask *)postParameter:(NSDictionary *)dictParameter
                                Success:(void (^)(NSURLSessionDataTask *operation, id responseObject))success
                                Failure:(void (^)(NSURLSessionDataTask *operation, NSError *error))failure
{
    return [TrackActionServiceManager postParameter:dictParameter PostData:nil Success:success Failure:failure];
}

/*
 2.1、POST方法, 提交数据, 需要传入方法名及参数(NSDictionary *)
 */
+ (NSURLSessionDataTask *)postParameter:(NSDictionary *)dictParameter
                               PostData:(NSData *)postData
                                Success:(void (^)(NSURLSessionDataTask *operation, id responseObject))success
                                Failure:(void (^)(NSURLSessionDataTask *operation, NSError *error))failure
{

    NSString *userID = @"0";//必须默认0
    if ([AppDelegate trackGetUserID].length>0) {
        userID = [AppDelegate trackGetUserID];
    }
    NSMutableDictionary *dictParams = [[NSMutableDictionary alloc] init];
    [dictParams addEntriesFromDictionary: @{
                                            //时间差
                                            @"timestamp" : KStringIsEmpty([TrackActionServiceManager GetTimeStamp]),
                                            //userid
                                            @"userid" : KStringIsEmpty(userID),
                                            //应用名称
                                            @"productName" : kDisplayName,
                                            //bundleId
                                            @"productID" : [[NSBundle mainBundle] bundleIdentifier],
                                            //应用版本号
                                            @"version" : kVersion,
                                            //设备版本
                                            @"osVersion" : [NSString stringWithFormat:@"%.1f",[DeviceAndSystemTool systemVersion]],
                                            //设备机型
                                            @"osDeviceType" : KStringIsEmpty([DeviceAndSystemTool getDeviceName]),
                                            //网络类型
                                            @"networkType" : KStringIsEmpty([DeviceAndSystemTool networkTypeName]),
                                            //运营商
                                            @"isp" : KStringIsEmpty([DeviceAndSystemTool wsd_telephonyNetworkInfo]),

                                            @"gps" : KStringIsEmpty([[LogDAO sharedInstance] getLocationInfo])
                                            }];
    [dictParams addEntriesFromDictionary:KDictionaryIsEmpty(dictParameter)? @{} : dictParameter];

    NSData *data=[NSJSONSerialization dataWithJSONObject:dictParams options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];

    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];

    [[self  sharedManager] logGetParameters:dictParams url:[AppDelegate trackServiceURL]];
    return  [[self sharedManager] POST:[AppDelegate trackServiceURL]
                            parameters:@{@"data" :mutStr}
             constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
             {
                 if(postData)
                 {
                     [formData appendPartWithFormData:postData name:@"postData"];
                 }
             }
                               success:success
                               failure:failure
             ];
}

+ (NSString *)GetTimeStamp {

    //记录本地和服务器的时间差
    NSDate *localNowDate = [NSDate dateWithTimeIntervalSinceNow:0];
    NSInteger localTimestamp = [localNowDate timeIntervalSince1970];
    NSInteger timestamp = localTimestamp + [TrackActionServiceManager sharedManager].timeOffset;

    NSString *timestampString = [NSString stringWithFormat:@"%ld",timestamp];

    return timestampString;

}


- (void)logGetParameters:(NSMutableDictionary *)parameters url:(NSString *)strBaseUrl{


    NSMutableString *rStr = [NSMutableString stringWithFormat:@"%@?",strBaseUrl];
    [((NSDictionary *)parameters) enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [rStr appendFormat:@"%@=%@&",key,obj];
    }];
    [rStr deleteCharactersInRange:NSMakeRange(rStr.length - 1, 1)];
    NSLog(@"URL请求参数拼接%@",rStr);

}


@end

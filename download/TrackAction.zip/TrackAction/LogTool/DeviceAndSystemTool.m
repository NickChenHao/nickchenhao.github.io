//
//  ZCDeviceAndSystemTool.m
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import "DeviceAndSystemTool.h"
#import <sys/utsname.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <net/if.h>
#import <UIKit/UIKit.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <LocalAuthentication/LocalAuthentication.h>
#define IOS_CELLULAR    @"pdp_ip0"
#define IOS_WIFI        @"en0"
#define IOS_VPN         @"utun0"
#define IP_ADDR_IPv4    @"ipv4"
#define IP_ADDR_IPv6    @"ipv6"

NSString * const kMSCNetworkTypeChangedNotification = @"kMSCNetworkTypeChangedNotification";

static void msc_reachabilityCallback(SCNetworkReachabilityRef target, SCNetworkReachabilityFlags flags, void* info)
{
    NSCAssert(info != NULL, @"info was NULL in msc_reachabilityCallback");
    
    if ([(__bridge NSObject *)info isKindOfClass:DeviceAndSystemTool.class]) {
        DeviceAndSystemTool* noteObject = (__bridge DeviceAndSystemTool *)info;
        // Post a notification to notify the client that the network reachability changed.
        [[NSNotificationCenter defaultCenter] postNotificationName: kMSCNetworkTypeChangedNotification object: noteObject];
    }
    else {
//#if DEBUG
//        NSLog(@"【info was wrong class in msc_reachabilityCallback】");
//#endif
    }
}
@interface DeviceAndSystemTool ()
{
    SCNetworkReachabilityRef _reachabilityRef;
}

@end

@implementation DeviceAndSystemTool

#pragma mark - 判断设备类型
//判断是否为手机
+ (BOOL)deviceIsPhone {
    
    BOOL _isIdiomPhone = YES;// 默认是手机
    UIDevice *currentDevice = [UIDevice currentDevice];
    // 设备是手机（包括iTouch）T
    if (currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPhone) {
        
        _isIdiomPhone = YES;
        
    }else if (currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad){
           // 设备室pad
        _isIdiomPhone = NO;
    }
    
    return _isIdiomPhone;
}

+ (float)systemVersion {
    //使用UIDevice设别类获取版本, 名字.....
    return [[[UIDevice currentDevice] systemVersion] floatValue];
}

/** 是大于等于iOS8 */
+ (BOOL)systemIsGreaterThanIOS8 {
    
    return (([DeviceAndSystemTool systemVersion] >= 8.0) ? YES : NO);
    
}

+ (BOOL)systemIsGreaterThanIOS8_2 {
    
    return (([DeviceAndSystemTool systemVersion] >= 8.2) ? YES : NO);
}

/** 是大于等于iOS9 */
+ (BOOL)systemIsGreaterThanIOS9 {
    
    return (([DeviceAndSystemTool systemVersion] >= 9.0) ? YES : NO);
    
}

/** 是大于等于iOS10 */
+ (BOOL)systemIsGreaterThanIOS10 {
    
    return (([DeviceAndSystemTool systemVersion] >= 10.0) ? YES : NO);
    
}

/** 是大于等于iOS11 */
+ (BOOL)systemIsGreaterThanIOS11 {
    
    return (([DeviceAndSystemTool systemVersion] >= 11.0) ? YES : NO);
    
}

/** 是大于等于iOS12 */
+ (BOOL)systemIsGreaterThanIOS12{
    
     return (([DeviceAndSystemTool systemVersion] >= 12.0) ? YES : NO);
}

/** 设备是否为iPhone 4/4S 分辨率320x480，像素640x960，@2x */
+ (BOOL)deviceIsIPhone4_4s {
    
    return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO);
    
}
/** 设备是否为iPhone 5C/5/5S/SE  分辨率320x568，像素640x1136，@2x */
+ (BOOL)deviceIsIPhone5_5s_5c_SE {
    
    return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO);
}
/** 设备是否为iPhone 6/6s/7/8 分辨率375x667，像素750x1334，@2x */
+ (BOOL)deviceIsIPhone6_6s_7_8 {
    
    return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO);
}
/** 设备是否为iPhone 6p/6sp/7p/8p 分辨率414x736，像素1242x2208，@3x */
+ (BOOL)deviceIsIPhone6P_6sP_7P_8P {
    
     return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO);
    
}
/** 设备是否为iPhone X 分辨率375x812，像素1125x2436，@3x */
+ (BOOL)deviceIsIPhoneX_XR {
    
    return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO);
    
}
+ (BOOL)deviceIsIPhoneXS_Max_XR{
    
    return ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) : NO);
}


#pragma mark - 获取设备名称
+ (NSString *)getDeviceName {
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    
    NSDictionary *platformList = @{
                                   //iphone
                                   @"iPhone3,1" : @"iPhone 4",
                                   @"iPhone3,2" : @"iPhone 4",
                                   @"iPhone3,3" : @"iPhone 4",
                                   @"iPhone4,1" : @"iPhone 4S",
                                   @"iPhone5,1" : @"iPhone 5",
                                   @"iPhone5,2" : @"iPhone 5",
                                   @"iPhone5,3" : @"iPhone 5c",
                                   @"iPhone5,4" : @"iPhone 5c",
                                   @"iPhone6,1" : @"iPhone 5s",
                                   @"iPhone6,2" : @"iPhone 5s",
                                   @"iPhone7,2" : @"iPhone 6",
                                   @"iPhone7,1" : @"iPhone 6 Plus",
                                   @"iPhone8,1" : @"iPhone 6s",
                                   @"iPhone8,2" : @"iPhone 6s Plus",
                                   @"iPhone8,4" : @"iPhone SE",
                                   @"iPhone9,1" : @"iPhone 7",
                                   @"iPhone9,3" : @"iPhone 7",
                                   @"iPhone9,2" : @"iPhone 7 Plus",
                                   @"iPhone9,4" : @"iPhone 7 Plus",
                                   @"iPhone10,1" : @"iPhone 8",
                                   @"iPhone10,4" : @"iPhone 8",
                                   @"iPhone10,2" : @"iPhone 8 Plus",
                                   @"iPhone10,5" : @"iPhone 8 Plus",
                                   @"iPhone10,3" : @"iPhone X",
                                   @"iPhone10,6" : @"iPhone X",
                                    //iPod Touch
                                   @"iPod1,1" : @"iPod Touch",
                                   @"iPod2,1" : @"iPod Touch 2G",
                                   @"iPod3,1" : @"iPod Touch 3G",
                                   @"iPod4,1" : @"iPod Touch 4G",
                                   @"iPod5,1" : @"iPod Touch 5G",
                                   @"iPod7,1" : @"iPod Touch 6G",
                                   //iPad
                                   @"iPad1,1" : @"iPad",
                                   @"iPad2,1" : @"iPad 2",
                                   @"iPad2,2" : @"iPad 2",
                                   @"iPad2,3" : @"iPad 2",
                                   @"iPad2,4" : @"iPad 2",
                                   @"iPad3,1" : @"iPad 3",
                                   @"iPad3,2" : @"iPad 3",
                                   @"iPad3,3" : @"iPad 3",
                                   @"iPad3,4" : @"iPad 4",
                                   @"iPad3,5" : @"iPad 4",
                                   @"iPad3,6" : @"iPad 4",
                                    //iPad Air
                                   @"iPad4,1" : @"iPad Air",
                                   @"iPad4,2" : @"iPad Air",
                                   @"iPad4,3" : @"iPad Air",
                                   @"iPad5,3" : @"iPad Air 2",
                                   @"iPad5,4" : @"iPad Air 2",
                                    //iPad mini
                                   @"iPad2,5" : @"iPad mini 1G",
                                   @"iPad2,6" : @"iPad mini 1G",
                                   @"iPad2,7" : @"iPad mini 1G",
                                   @"iPad4,4" : @"iPad mini 2",
                                   @"iPad4,5" : @"iPad mini 2",
                                   @"iPad4,6" : @"iPad mini 2",
                                   @"iPad4,7" : @"iPad mini 3",
                                   @"iPad4,8" : @"iPad mini 3",
                                   @"iPad4,9" : @"iPad mini 3",
                                   @"iPad5,1" : @"iPad mini 4",
                                   @"iPad5,2" : @"iPad mini 4",
                                   //iPad Pro
                                   @"iPad6,3" : @"iPad Pro (9.7 inch)",
                                   @"iPad6,4" : @"iPad Pro (9.7 inch)",
                                   @"iPad6,7" : @"iPad Pro (12.9 inch)",
                                   @"iPad6,8" : @"iPad Pro (12.9 inch)",
                                   //iPhone Simulator
                                   @"i386" : @"iPhone Simulator",
                                   @"x86_64" : @"iPhone Simulator",
                                   
                                   };
    
    NSString *deviceName = platformList[platform];
    if (deviceName != nil && ![deviceName isEqualToString:@""]) {
        return deviceName;
    }
    
    return platform;
    
}

#pragma mark - 当前网络类型
+ (instancetype)sharedInstance
{
    static dispatch_once_t s_onceToken;
    static id s_sharedInstance;
    dispatch_once(&s_onceToken, ^{
        s_sharedInstance = [self new];
    });
    
    return s_sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    
    if (self)
    {
        [self setupMonitor];
        [self startMonitor];
    }
    
    return self;
}

#pragma mark - 辅助函数
- (void)setupMonitor
{
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    SCNetworkReachabilityRef reachability = SCNetworkReachabilityCreateWithAddress(kCFAllocatorDefault, (const struct sockaddr *)&zeroAddress);
    
    if (reachability != NULL)
    {
        self->_reachabilityRef = reachability;
    }
}

#pragma mark - Start and stop monitor
- (BOOL)startMonitor
{
    BOOL returnValue = NO;
    SCNetworkReachabilityContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
    
    if (SCNetworkReachabilitySetCallback(_reachabilityRef, msc_reachabilityCallback, &context))
    {
        if (SCNetworkReachabilityScheduleWithRunLoop(_reachabilityRef, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode))
        {
            returnValue = YES;
        }
    }
    
    return returnValue;
}


- (void)stopMonitor
{
    if (_reachabilityRef != NULL)
    {
        SCNetworkReachabilityUnscheduleFromRunLoop(_reachabilityRef, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
    }
}


- (void)dealloc
{
    [self stopMonitor];
    
    if (_reachabilityRef != NULL)
    {
        CFRelease(_reachabilityRef);
    }
}
#pragma mark - Network Flag Handling
- (MSCNetworkType)networkTypeForFlags:(SCNetworkReachabilityFlags)flags
{
    if ((flags & kSCNetworkReachabilityFlagsReachable) == 0)
    {
        return kMSCNetworkTypeNone;
    }
    
    MSCNetworkType returnValue = kMSCNetworkTypeNone;
    
    if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0)
    {
        returnValue = kMSCNetworkTypeWiFi;
    }
    
    if ((((flags & kSCNetworkReachabilityFlagsConnectionOnDemand ) != 0) ||
         (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0))
    {
        if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0)
        {
            returnValue = kMSCNetworkTypeWiFi;
        }
    }
    
    if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
    {
        if (floor(NSFoundationVersionNumber) > floor(993.00)) // iOS 7+ (NSFoundationVersionNumber_iOS_6_1)
        {
            CTTelephonyNetworkInfo * info = [[CTTelephonyNetworkInfo alloc] init];
            NSString *currentRadioAccessTechnology = info.currentRadioAccessTechnology;
            
            if (currentRadioAccessTechnology)
            {
                if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyLTE])
                {
                    returnValue =  kMSCNetworkType4G;
                }
                else if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyEdge] || [currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyGPRS])
                {
                    returnValue =  kMSCNetworkType2G;
                }
                else
                {
                    returnValue =  kMSCNetworkType3G;
                }
                
                return returnValue;
            }
        }
        
        if ((flags & kSCNetworkReachabilityFlagsTransientConnection) == kSCNetworkReachabilityFlagsTransientConnection)
        {
            if((flags & kSCNetworkReachabilityFlagsConnectionRequired) == kSCNetworkReachabilityFlagsConnectionRequired)
            {
                returnValue =  kMSCNetworkType2G;
                return returnValue;
            }
            
            returnValue =  kMSCNetworkType3G;
            return returnValue;
        }
        
        returnValue = kMSCNetworkTypeWWAN;
    }
    
    return returnValue;
}

- (MSCNetworkType)currentNetworkType
{
    NSAssert(_reachabilityRef != NULL, @"currentNetworkType called with NULL SCNetworkReachabilityRef");
    
    MSCNetworkType returnValue = kMSCNetworkTypeNone;
    SCNetworkReachabilityFlags flags;
    
    if (SCNetworkReachabilityGetFlags(_reachabilityRef, &flags)){
        returnValue = [self networkTypeForFlags:flags];
    }
    
    return returnValue;
}

+ (MSCNetworkType)networkType
{
    return [[DeviceAndSystemTool new] currentNetworkType];
}

+ (NSString *)networkTypeName
{
    NSString *string = @"*****";
    
    switch ([DeviceAndSystemTool networkType])
    {
        case kMSCNetworkTypeNone:
            NSLog(@"NotReachable");
            string = @"无网络";
            break;
            
        case kMSCNetworkTypeWiFi:
            NSLog(@"ReachableViaWiFi");
            string = @"WiFi";
            break;
            
        case kMSCNetworkTypeWWAN:
            NSLog(@"ReachableViaWWAN");
            string = @"WWAN";
            break;
            
        case kMSCNetworkType2G:
            NSLog(@"kReachableVia2G");
            string = @"2G";
            break;
            
        case kMSCNetworkType3G:
            NSLog(@"kReachableVia3G");
            string = @"3G";
            break;
            
        case kMSCNetworkType4G:
            NSLog(@"kReachableVia4G");
            string = @"4G";
            break;
        default:
            NSLog(@"default");
            string = @"default";
            break;
    }
    
    return string;
    
}


+ (NSString *)wsd_telephonyNetworkInfo{
    
    CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *ybs_carrier = [telephonyInfo subscriberCellularProvider];
    NSString *carrierName = [ybs_carrier carrierName];
    return carrierName;
}



#pragma mark - 当前设备IP地址
+ (NSString *)getIPAddress:(BOOL)netWorkisIPV4 {
    
    NSArray *searchArray = netWorkisIPV4 ?
    @[ IOS_VPN @"/" IP_ADDR_IPv4, IOS_VPN @"/" IP_ADDR_IPv6, IOS_WIFI @"/" IP_ADDR_IPv4, IOS_WIFI @"/" IP_ADDR_IPv6, IOS_CELLULAR @"/" IP_ADDR_IPv4, IOS_CELLULAR @"/" IP_ADDR_IPv6 ] :
    @[ IOS_VPN @"/" IP_ADDR_IPv6, IOS_VPN @"/" IP_ADDR_IPv4, IOS_WIFI @"/" IP_ADDR_IPv6, IOS_WIFI @"/" IP_ADDR_IPv4, IOS_CELLULAR @"/" IP_ADDR_IPv6, IOS_CELLULAR @"/" IP_ADDR_IPv4 ] ;
    
    NSDictionary *addresses = getIPAddress();
    //    NSLog(@"addresses: %@", addresses);
    
    __block NSString *address;
    [searchArray enumerateObjectsUsingBlock:^(NSString *key, NSUInteger idx, BOOL *stop)
     {
         address = addresses[key];
         //筛选出IP地址格式
         if(validateIPAddress(address)) *stop = YES;
     } ];
    return address ? address : @"0.0.0.0";
}

//验证ip地址
static inline BOOL validateIPAddress(NSString *ipAddress){
    if (ipAddress.length == 0) {
        return NO;
    }
    NSString *urlRegEx = @"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:urlRegEx options:0 error:&error];
    
    if (regex != nil) {
        NSTextCheckingResult *firstMatch=[regex firstMatchInString:ipAddress options:0 range:NSMakeRange(0, [ipAddress length])];
        
        if (firstMatch) {
            NSRange resultRange = [firstMatch rangeAtIndex:0];
            NSString *result=[ipAddress substringWithRange:resultRange];
            //输出结果
            NSLog(@"%@",result);
            return YES;
        }
    }
    return NO;
    
}

static inline NSDictionary * getIPAddress(){
    NSMutableDictionary *addresses = [NSMutableDictionary dictionaryWithCapacity:8];
    
    // retrieve the current interfaces - returns 0 on success
    struct ifaddrs *interfaces;
    if(!getifaddrs(&interfaces)) {
        // Loop through linked list of interfaces
        struct ifaddrs *interface;
        for(interface=interfaces; interface; interface=interface->ifa_next) {
            if(!(interface->ifa_flags & IFF_UP) /* || (interface->ifa_flags & IFF_LOOPBACK) */ ) {
                continue; // deeply nested code harder to read
            }
            const struct sockaddr_in *addr = (const struct sockaddr_in*)interface->ifa_addr;
            char addrBuf[ MAX(INET_ADDRSTRLEN, INET6_ADDRSTRLEN) ];
            if(addr && (addr->sin_family==AF_INET || addr->sin_family==AF_INET6)) {
                NSString *name = [NSString stringWithUTF8String:interface->ifa_name];
                NSString *type;
                if(addr->sin_family == AF_INET) {
                    if(inet_ntop(AF_INET, &addr->sin_addr, addrBuf, INET_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv4;
                    }
                } else {
                    const struct sockaddr_in6 *addr6 = (const struct sockaddr_in6*)interface->ifa_addr;
                    if(inet_ntop(AF_INET6, &addr6->sin6_addr, addrBuf, INET6_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv6;
                    }
                }
                if(type) {
                    NSString *key = [NSString stringWithFormat:@"%@/%@", name, type];
                    addresses[key] = [NSString stringWithUTF8String:addrBuf];
                }
            }
        }
        // Free memory
        freeifaddrs(interfaces);
    }
    return [addresses count] ? addresses : nil;
    
}



+ (BOOL)wsd_juggleUIUserNotificationSettings{
    
    
    if ([self systemIsGreaterThanIOS8]) {
        UIUserNotificationSettings *setting = [[UIApplication sharedApplication] currentUserNotificationSettings];
        return (setting.types == UIUserNotificationTypeNone)? false : true;
    }else{
        UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        return (type == UIRemoteNotificationTypeNone)? false : true;
    }
}

#pragma mark - 判断是否支持指纹
+(BOOL)isSupportAndHaveFingerprint{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 9.0) {
        //获取上下文
        LAContext *myContext = [[LAContext alloc]init];
        NSError *error = nil;
        if (![myContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
            //不支持指纹识别，LOG出错误详情
            switch (error.code) {
                case LAErrorTouchIDNotEnrolled:
                {
                    return NO;
                    //NSLog(@"TouchID is not enrolled");
                    break;
                }
                case LAErrorPasscodeNotSet:
                {
                    //NSLog(@"A passcode has not been set");
                    return NO;
                    break;
                }
                case LAErrorTouchIDNotAvailable:
                {
                    NSLog(@"触摸ID在设备上不可用");
                     return NO;
                    break;
                }
                case LAErrorTouchIDLockout:
                {
                    NSLog(@"源自用户多次连续使用Touch ID失败");
                    return YES;
                    break;
                }
                    
                default:
                {
                    //NSLog(@"TouchID not available");
                    return NO;
                    break;
                }
            }
            
            return NO;
        }
        else{
            if ([self deviceIsIPhoneX_XR] || [self deviceIsIPhoneXS_Max_XR]) {
                return NO;
            }
            return YES;
        }
       
    }else{
        return NO;
    }
    return YES;
}

@end

#pragma mark - 初始化单例
@interface UIResponder(EXNetState)
@end

@implementation UIResponder(EXNetState)

+(void)initialize
{
    if ([@"UIResponder" isEqualToString:NSStringFromClass(self.class)]) {
//        NSLog(@"class:%@ -- initialize", NSStringFromClass(self.class));
        [DeviceAndSystemTool sharedInstance];
    }
}

@end

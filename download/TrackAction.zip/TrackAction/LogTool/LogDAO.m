//
//  LogDAO.m
//  Nick
//
//  Created by nick on 2019/6/19.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "LogDAO.h"
#import <CoreLocation/CoreLocation.h>

@interface LogDAO ()<CLLocationManagerDelegate>
@property (nonatomic, strong) CLLocationManager* locationManager;
@end

@implementation LogDAO
static LogDAO *sharedInstace = nil;

+ (instancetype)sharedInstance {
    return [[self alloc] init];
}

- (instancetype)init {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstace = [super init];
        [self setLocationInfo];
    });
    return sharedInstace;
}


- (BOOL)insertLogDTO:(nonnull NSArray <LogDTO *> *)array {
    if ([self isExsitWithDTO:array]) {
        return [self updateLogDTO:array];
    }
    @weakify(array)
    __block BOOL insertScuccess = YES;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        @normalize(array)
        [array enumerateObjectsUsingBlock:^(LogDTO * _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *sql = [NSString stringWithFormat:@"INSERT INTO info_log (vc_id,btn_id,num,functionName,remainTime,lastTime,logType) values (?,?,?,?,?,?,?)"];
            if (![db executeUpdate:sql,model.vc_id,model.btn_id,@(model.num),model.functionName,@(model.remainTime),@(model.lastTime),@(model.logType)]) {
                *rollback = YES;
                DLog(@"添加失败");
                insertScuccess = NO;
                return ;
            }
        }];
    }];
    DLog(@"表行数：%zd",[self getCountOfRow]);

//    if ([self getCountOfRow] > 2000) { //表行大于2000 清除表数据
//        [self deleteLogTable];
//    }
    return insertScuccess;
}

- (BOOL)updateLogDTO:(nonnull NSArray <LogDTO *> *)array {
    if (![self isExsitWithDTO:array]) {
       return [self insertLogDTO:array];
    }
    @weakify(array)
    __block BOOL updateSuccess = YES;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        @normalize(array)
        [array enumerateObjectsUsingBlock:^(LogDTO * _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *sql = [NSString stringWithFormat:@"UPDATE info_log SET num = ? WHERE vc_id = ? AND btn_id = ?"];
            if (![db executeUpdate:sql,@(model.num),model.vc_id,model.btn_id]) {
                *rollback = YES;
                updateSuccess = NO;
                return ;
            }
        }];
    }];
//    if ([self getCountOfRow] > 2000) { //表行大于2000 清除表数据
//        [self deleteLogTable];
//    }
    return updateSuccess;
}

- (BOOL)deleteLogTable {
    __block BOOL deleteSuccess = YES;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"DELETE FROM info_log";
        if (![db executeUpdate:sql]) {
            *rollback = YES;
            deleteSuccess = NO;
            return ;
        }
    }];
    DLog(@"删表");
    return deleteSuccess;
}

- (NSInteger)getBtnClickNumWithLogDTO:(LogDTO *)model {
    if (![self isExsitWithDTO:@[model]]) {
        return 0;
    }
    __block NSInteger num = 0;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"SELECT * FROM info_log WHERE vc_id = ? AND btn_id = ?";
        FMResultSet *rs = [db executeQuery:sql, model.vc_id,model.btn_id];
        while ([rs next]) {
            int tempNum = [rs intForColumn:@"num"];
            num += tempNum;
        }
        [rs close];
    }];
    return num;
}

- (NSArray *)getCountOfKindVC {
    __block NSArray *results;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"SELECT * FROM info_log";
        NSMutableArray *ar = [NSMutableArray array];
        FMResultSet *rs = [db executeQuery:sql];
        while ([rs next]) {

            NSString *vcId = [rs stringForColumn:@"vc_id"];
            if (![ar containsObject:vcId]) {
                [ar addObject:vcId];
            }
        }
        [rs close];
        results = [ar copy];
    }];
    return results;
}

- (NSArray *)getAllBtns{
    __block NSArray *results;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"SELECT * FROM info_log";
        NSMutableArray *ar = [NSMutableArray array];
        FMResultSet *rs = [db executeQuery:sql];
        while ([rs next]) {
            LogDTO *model = [LogDTO new];
            model.vc_id = [rs stringForColumn:@"vc_id"];
            model.btn_id = [rs stringForColumn:@"btn_id"];
            model.num = [rs intForColumn:@"num"];
            [ar addObject:model];
        }
        [rs close];

        results = [ar copy];
    }];
    return results;
}

- (NSArray *)getAllData{
    __block NSArray *results;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"SELECT * FROM info_log";
        NSMutableArray *ar = [NSMutableArray array];
        FMResultSet *rs = [db executeQuery:sql];
        while ([rs next]) {
            LogDTO *model = [LogDTO new];
            model.vc_id = [rs stringForColumn:@"vc_id"];
            model.btn_id = [rs stringForColumn:@"btn_id"];
            model.num = [rs intForColumn:@"num"];
            model.functionName = [rs stringForColumn:@"functionName"];
            model.remainTime = [rs doubleForColumn:@"remainTime"];
            model.lastTime = [rs doubleForColumn:@"lastTime"];
            model.logType = [rs intForColumn:@"logType"];
            [ar addObject:model];
        }
        [rs close];
        results = [ar copy];
    }];
    return results;
}

- (NSInteger)getCountOfRow{
    __block NSInteger sum;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        NSString *sql = @"SELECT COUNT(*) from info_log";
        FMResultSet *rs = [db executeQuery:sql];
        if ([rs next]) {
            sum = [rs intForColumnIndex:0];
        }
        [rs close];
    }];
    return sum;
}


#pragma mark -
#pragma mark setter && getter

#pragma  mark -
#pragma mark helper

- (BOOL)isExsitWithDTO:(nonnull NSArray <LogDTO *> *)array {
    //因为不同的界面按钮也不同 多条件检索
    @weakify(array)
    __block BOOL hasValue = NO;
    [self.databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        @normalize(array)
        [array enumerateObjectsUsingBlock:^(LogDTO * _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *sql = [NSString stringWithFormat:@"SELECT * FROM info_log where vc_id = ? AND btn_id = ?"];
            FMResultSet *rs = [db executeQuery:sql, model.vc_id,model.btn_id];
            if (!rs) {
                [rs close];
                return ;
            }
            if ([rs next]) { hasValue = YES; }
            [rs close];
        }];
    }];
    return hasValue;
}



#pragma mark - 定位
- (void)setLocationInfo {

    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [self restartGetLocationInfo];

}

- (void)restartGetLocationInfo {

    if ([CLLocationManager locationServicesEnabled] && ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways)) {

        [self.locationManager startUpdatingLocation];
    }
}


- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {

    if ([CLLocationManager locationServicesEnabled] && ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways)) {

        //         1.获取用户位置的对象
        CLLocation *location = [locations lastObject];

        [self reverseGeocodeWithLocation:location];

    }
    // 2.停止定位
    [manager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {

    if (error.code == kCLErrorDenied) {
        NSLog(@"获取定位失败");
    }

}

// 反编译地理信息
- (void) reverseGeocodeWithLocation:(CLLocation *) location {

    if (!location) {
        return ;
    }

    CLGeocoder *coder = [[CLGeocoder alloc]init];
    [coder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {

        if (placemarks && placemarks.count > 0) {
            CLPlacemark *mark = [placemarks firstObject];

            // 省 市 区 地标
            self.strLocationInfo = [NSString stringWithFormat:@"%@ %@ %@ %@", mark.administrativeArea, mark.locality,mark.subLocality,mark.name];
        }
    }];
}

- (NSString *)getLocationInfo{
    return self.strLocationInfo;
}

#pragma mark - 服务器
- (void)uploadTrackDataToServerWithCompletion:(void (^)(BOOL, NSError * _Nullable))handler{


    if (self.isUpdate) {
        // 更新服务器上的数据
        [self updateDataToServiceWithCompletion:handler];
        return;
    }

#pragma mark - AFN
    //    NSDictionary *dic = @{
    //                          //模型数组转成字典数组
    //                          @"list": [LogDTO mj_keyValuesArrayWithObjectArray:[[LogDAO sharedInstance] getAllData]]
    //                          };
    //    [TrackActionServiceManager postParameter:dic Success:^(NSURLSessionDataTask *operation, id responseObject) {
    //
    //        if (handler) {
    //            handler(YES,nil);
    //        }
    //
    //    } Failure:^(NSURLSessionDataTask *operation, NSError *error) {
    //
    //        if (handler) {
    //            handler(NO,error);
    //        }
    //    }];



#pragma mark - 后端云SDK
    NSString *userID = @"0";//必须默认0
    if ([AppDelegate trackGetUserID].length>0) {
        userID = [AppDelegate trackGetUserID];
    }
    NSDictionary *dic = @{
                          //模型数组转成字典数组
                          @"list" : [LogDTO mj_keyValuesArrayWithObjectArray:[[LogDAO sharedInstance] getAllData]],
                          //userid
                          @"userid" : KStringIsEmpty(userID),
                          //应用名称
                          @"productName" : kDisplayName,
                          //bundleId
                          @"productID" : [[NSBundle mainBundle] bundleIdentifier],
                          //应用版本号
                          @"version" : kVersion,
                          //设备版本
                          @"osVersion" : [NSString stringWithFormat:@"%.1f",[DeviceAndSystemTool systemVersion]],
                          //设备机型
                          @"osDeviceType" : KStringIsEmpty([DeviceAndSystemTool getDeviceName]),
                          //网络类型
                          @"networkType" : KStringIsEmpty([DeviceAndSystemTool networkTypeName]),
                          //运营商
                          @"isp" : KStringIsEmpty([DeviceAndSystemTool wsd_telephonyNetworkInfo]),
                          //定位（省市区）
                          @"gps" : KStringIsEmpty(self.strLocationInfo)
                          };

    BmobObject *trackBmob = [BmobObject objectWithClassName:@"TrackAction"];
    [trackBmob setObject:dic forKey:@"TrackData"];
    [trackBmob setObject:[AppDelegate trackGetUserID] forKey:@"UserID"];
    [trackBmob saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        //进行操作
        if (isSuccessful) {
            if (handler) {
                handler(YES,nil);
            }
        }else{
            if (handler) {
                handler(NO,error);
            }
        }
    }];
}

- (void)getTrackDataFromServer{

    //创建查表对象
    BmobQuery   *bquery = [BmobQuery queryWithClassName:@"TrackAction"];
    //设置查询中该字段是有值的结果
    [bquery whereKeyExists:@"UserID"];
    //设置查询中该字段 值是否相等的结果
    [bquery whereKey:@"UserID" equalTo:[AppDelegate trackGetUserID]];
    //查询
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error){
            //进行错误处理
        }else{
            if (array) {

//                NSMutableArray *dataArray = [NSMutableArray array];
//                [array enumerateObjectsUsingBlock:^(BmobObject * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//
//                    NSDictionary *trackData = [obj objectForKey:@"TrackData"];
//                    NSArray *list = [trackData objectForKey:@"list"];
//                    if (list.count) {
//                        // 字典数组 转 LogDTO模型数组
//                        NSArray *tempArray = [LogDTO mj_objectArrayWithKeyValuesArray:list];
//                        [dataArray addObjectsFromArray:tempArray];
//                    }
//                }];
//                if (dataArray.count) {
//                    // 插入数据库
//                    [[LogDAO sharedInstance] insertLogDTO:[dataArray copy]];
//                }

            }
            self.isUpdate = array.count;
        }
    }];


}

- (void)updateDataToServiceWithCompletion:(void (^)(BOOL, NSError * _Nullable))handler{
    //创建查表对象
    BmobQuery   *bquery = [BmobQuery queryWithClassName:@"TrackAction"];
    //设置查询中该字段是有值的结果
    [bquery whereKeyExists:@"UserID"];
    //设置查询中该字段 值是否相等的结果
    [bquery whereKey:@"UserID" equalTo:[AppDelegate trackGetUserID]];
    //查询
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error){
            //进行错误处理
        }else{
            if (array) {
                BmobObject *obj = array[0];

                NSString *userID = @"0";//必须默认0
                if ([AppDelegate trackGetUserID].length>0) {
                    userID = [AppDelegate trackGetUserID];
                }
                NSDictionary *dic = @{
                                      //模型数组转成字典数组
                                      @"list" : [LogDTO mj_keyValuesArrayWithObjectArray:[[LogDAO sharedInstance] getAllData]],
                                      //userid
                                      @"userid" : KStringIsEmpty(userID),
                                      //应用名称
                                      @"productName" : kDisplayName,
                                      //bundleId
                                      @"productID" : [[NSBundle mainBundle] bundleIdentifier],
                                      //应用版本号
                                      @"version" : kVersion,
                                      //设备版本
                                      @"osVersion" : [NSString stringWithFormat:@"%.1f",[DeviceAndSystemTool systemVersion]],
                                      //设备机型
                                      @"osDeviceType" : KStringIsEmpty([DeviceAndSystemTool getDeviceName]),
                                      //网络类型
                                      @"networkType" : KStringIsEmpty([DeviceAndSystemTool networkTypeName]),
                                      //运营商
                                      @"isp" : KStringIsEmpty([DeviceAndSystemTool wsd_telephonyNetworkInfo]),
                                      //定位（省市区）
                                      @"gps" : KStringIsEmpty(self.strLocationInfo)
                                      };

                BmobObject *obj1 = [BmobObject objectWithoutDataWithClassName:obj.className objectId:obj.objectId];
                //设置cheatMode为YES
                [obj1 setObject:dic forKey:@"TrackData"];
                //异步更新数据
                [obj1 updateInBackground];
            }
        }
    }];
}
@end

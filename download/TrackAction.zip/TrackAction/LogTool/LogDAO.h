//
//  LogDAO.h
//  Nick
//
//  Created by nick on 2019/6/19.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "DAO.h"
#import "LogDTO.h"

/** 专门处理数据库 */
NS_ASSUME_NONNULL_BEGIN

@interface LogDAO : DAO

//定位数据
@property (nonatomic, copy) NSString *strLocationInfo;
//标记是更新还是新增
@property (nonatomic, assign) BOOL isUpdate;

/** 创建一个单例类 */
+ (instancetype)sharedInstance;

/** 添加log信息 */
- (BOOL)insertLogDTO:(nonnull NSArray <LogDTO *> *)array;

/** 更新log信息到数据库 */
- (BOOL)updateLogDTO:(nonnull NSArray <LogDTO *> *)array;

/** 删除表 */
- (BOOL)deleteLogTable;

/** 根据模型获得某个界面某个按钮点击次数 */
- (NSInteger)getBtnClickNumWithLogDTO:(nonnull LogDTO *)model;

/** 获得所有界面 vcId区分 */
- (NSArray *)getCountOfKindVC;

/** 获得所有按钮 */
- (NSArray *)getAllBtns;
/** 获得所有数据 */
- (NSArray *)getAllData;
/** 获取表 行数 */
- (NSInteger)getCountOfRow;

/** 检测模型是否存在 */
- (BOOL)isExsitWithDTO:(nonnull NSArray <LogDTO *> *)array;

/** 上传服务器 */
- (void)uploadTrackDataToServerWithCompletion:(void (^)(BOOL success, NSError *error))handler;

/** 获取服务器数据 */
- (void)getTrackDataFromServer;

/** 获取定位信息 */
- (NSString *)getLocationInfo;
@end
NS_ASSUME_NONNULL_END

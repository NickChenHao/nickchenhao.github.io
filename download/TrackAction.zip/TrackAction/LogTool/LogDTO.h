//
//  LogDTO.h
//  Nick
//
//  Created by nick on 2019/6/19.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, LogType) {
    LogTypeNone = 0,    // 未知
    LogTypeLaunch,      // app 启动或前台
    LogTypeButtonClick, // 按钮点击
    LogTypeCellClick,   // cell点击
    LogTypeVCRemainTime,// 界面停留时间
    LogTypeTerminated,  // app 终止或后台
};

//数据模型
@interface LogDTO : NSObject
@property (nonatomic, copy) NSString *vc_id;// 控制器名称 
@property (nonatomic) NSTimeInterval remainTime; //停留时间
@property (nonatomic, copy) NSString *btn_id;// 按钮名称
@property (nonatomic, copy) NSString *functionName;// 方法名称
@property (nonatomic, assign) NSInteger num;// 点击次数
@property (nonatomic) NSTimeInterval lastTime; //最后执行时间
@property (nonatomic, assign) LogType logType; //记录类型
@end

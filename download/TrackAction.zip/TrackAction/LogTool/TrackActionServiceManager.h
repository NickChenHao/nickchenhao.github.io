//
//  TrackActionServiceManager.h
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>


NS_ASSUME_NONNULL_BEGIN

@interface TrackActionServiceManager : AFHTTPSessionManager
@property(nonatomic,copy) NSString *deviceToken;



+ (instancetype)sharedManager;

+ (NSURLSessionDataTask *)postParameter:(NSDictionary *)dictParameter
                                Success:(void (^)(NSURLSessionDataTask *operation, id responseObject))success
                                Failure:(void (^)(NSURLSessionDataTask *operation, NSError *error))failure;
@end

NS_ASSUME_NONNULL_END

//
//  DeviceAndSystemTool.h
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import <Foundation/Foundation.h>
// 网络类型值
typedef NS_ENUM(NSInteger, MSCNetworkType) {
    kMSCNetworkTypeNone = 0, //当前没有网络
    kMSCNetworkTypeWiFi,
    kMSCNetworkTypeWWAN,
    kMSCNetworkType2G,
    kMSCNetworkType3G,
    kMSCNetworkType4G,
};

@interface DeviceAndSystemTool : NSObject

/** 判断设备是否是手机 */
+ (BOOL)deviceIsPhone;

/** 设备是否为iPhone 4/4S 分辨率320x480，像素640x960，@2x */
+ (BOOL)deviceIsIPhone4_4s;
/** 设备是否为iPhone 5C/5/5S/SE  分辨率320x568，像素640x1136，@2x */
+ (BOOL)deviceIsIPhone5_5s_5c_SE;
/** 设备是否为iPhone 6/6s/7/8 分辨率375x667，像素750x1334，@2x */
+ (BOOL)deviceIsIPhone6_6s_7_8;
/** 设备是否为iPhone 6p/6sp/7p/8p 分辨率414x736，像素1242x2208，@3x */
+ (BOOL)deviceIsIPhone6P_6sP_7P_8P;
/** 设备是否为iPhone X/XS 分辨率375x812，像素1125x2436，@3x */
+ (BOOL)deviceIsIPhoneX_XR;
/** 设备是否为iPhone XsMax/XR 分辨率375x812，像素1242x2688，@3x */
+ (BOOL)deviceIsIPhoneXS_Max_XR;

/** 获取系统版本 */
+ (float)systemVersion;
/** 是否大于等于iOS8 */
+ (BOOL)systemIsGreaterThanIOS8;
/** 是否大于等于iOS8.2 */
+ (BOOL)systemIsGreaterThanIOS8_2;
/** 是否大于等于iOS9 */
+ (BOOL)systemIsGreaterThanIOS9;
/** 是大于等于iOS10 */
+ (BOOL)systemIsGreaterThanIOS10;
/** 是大于等于iOS11 */
+ (BOOL)systemIsGreaterThanIOS11;
/** 是大于等于iOS12 */
+ (BOOL)systemIsGreaterThanIOS12;

/** 返回手机设备名字 */
+ (NSString *)getDeviceName;
/** 当前设备IP地址 */
+ (NSString *)getIPAddress:(BOOL)netWorkisIPV4;

/** 应用是否可以接收推送 */
+ (BOOL)wsd_juggleUIUserNotificationSettings;

/** 判断设备是否支持指纹 */

+(BOOL)isSupportAndHaveFingerprint;

/**
 *@brief 当前的网络状态
 */
+ (MSCNetworkType)networkType;
+ (NSString *)networkTypeName;

/** 运营商名称 */
+ (NSString *)wsd_telephonyNetworkInfo;






/**
 *@brief 单例
 */
+ (instancetype)sharedInstance;
@end
extern  NSString *const kMSCNetworkTypeChangedNotification;

//
//  DAO.h
//  pandamama_iosProject
//
//  Created by tree on 2019/6/24.
//  Copyright © 2017年 pandamama. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "DatabaseManager.h"
@interface DAO : NSObject
@property (nonatomic, strong) FMDatabaseQueue *databaseQueue;

+(void)createTablesNeeded;//创建数据库表
@end

//
//  DatabaseManager.h
//  pandamama_iosProject
//
//  Created by tree on 2019/6/24.
//  Copyright © 2017年 pandamama. All rights reserved.
//

#import <Foundation/Foundation.h>
@class FMDatabaseQueue;

@interface DatabaseManager : NSObject {
    BOOL _isInitializeSuccess;
    
    BOOL _isDataBaseOpened;
    
    NSString *_writablePath;
    
    FMDatabaseQueue *_databaseQueue;
}
@property (nonatomic, copy) NSString *writablePath;

@property (nonatomic, strong) FMDatabaseQueue *databaseQueue;

+ (DatabaseManager *)currentManager;

- (BOOL)isDataBaseOpened;

- (void)openDataBase;

- (void)closeDataBase;

@end

//
//  DatabaseManager.m
//  pandamama_iosProject
//
//  Created by tree on 2019/6/24.
//  Copyright © 2017年 pandamama. All rights reserved.
//

#import "DatabaseManager.h"
#import "FMDatabaseQueue.h"
#import "FMDatabase.h"
#import "PathConstant.h"
@implementation DatabaseManager
@synthesize writablePath = _writablePath;
@synthesize databaseQueue = _databaseQueue;

static DatabaseManager *_manager = nil;
- (id)init {
    self = [super init];
    if (self) {
        _isDataBaseOpened = NO;
        [self setWritablePath:[DatabaseDirectory() stringByAppendingPathComponent:kDatabaseFileName]];
         [self openDataBase];

    }
    return self;
}

- (void)openDataBase {
    DLog(@"%@",self.writablePath);
    _databaseQueue = [FMDatabaseQueue databaseQueueWithPath:self.writablePath];
    if (_databaseQueue == 0x00) {
        _isDataBaseOpened = NO;
        return;
    }
    _isDataBaseOpened = YES;
    DLog(@"Open Database OK!");
    [_databaseQueue inDatabase:^(FMDatabase *db) {
        [db setShouldCacheStatements:YES];
    }];
}
- (void)closeDataBase {
    if (!_isDataBaseOpened) {
        DLog(@"数据库已打开，或打开失败。请求关闭数据库失败。");
        return;
    }
    [_databaseQueue close];
    _isDataBaseOpened = NO;
    DLog(@"关闭数据库成功");
}

+(DatabaseManager *)currentManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!_manager) {
            _manager = [[DatabaseManager alloc] init];
        }
    });
    return _manager;
}

- (void)dealloc {
    [self closeDataBase];
}
#pragma mark -
#pragma mark setter&getter
- (BOOL)isDataBaseOpened {
    return _isDataBaseOpened;
}

@end

//
//  DAO.m
//  pandamama_iosProject
//
//  Created by tree on 2019/6/24.
//  Copyright © 2017年 pandamama. All rights reserved.
//

#import "DAO.h"

@implementation DAO
@synthesize databaseQueue = _databaseQueue;


- (id)init {
    self = [super init];
    if (self) {
        self.databaseQueue = [DatabaseManager currentManager].databaseQueue;
    }
    return self;
}

- (FMDatabaseQueue *)databaseQueue {
    if (![[DatabaseManager currentManager] isDataBaseOpened]) {
        [[DatabaseManager currentManager] openDataBase];
        self.databaseQueue = [DatabaseManager currentManager].databaseQueue;
        if (_databaseQueue) [DAO createTablesNeeded];
    }
    return _databaseQueue;
}

+ (void)createTablesNeeded {
    FMDatabaseQueue *databaseQueue = [DatabaseManager currentManager].databaseQueue;
    [databaseQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        //信息收集的表建立
        /** Log信息表 */
        NSString *sql1 = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS info_log (vc_id TEXT,btn_id TEXT,num integer,functionName TEXT,remainTime real,lastTime real,logType integer)"];

        for (NSString *sql in @[sql1]) {
            [db executeUpdate:sql];
        }
        
    }];
    DLog(@"数据库地址：%@", [DatabaseManager currentManager].writablePath);
}
@end

//
//  LogDTO.m
//  Nick
//
//  Created by nick on 2019/6/19.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "LogDTO.h"

@implementation LogDTO
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.vc_id = @"";
        self.remainTime = 0;
        self.btn_id = @"";
        self.functionName = @"";
        self.num = 1;
        self.lastTime = [[NSDate date] timeIntervalSince1970] * 1000;
        self.logType = LogTypeNone;
    }
    return self;
}
@end

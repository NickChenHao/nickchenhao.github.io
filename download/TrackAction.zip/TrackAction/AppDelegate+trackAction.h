//
//  AppDelegate+trackAction.h
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN


@interface AppDelegate (trackAction)

// 需要创建数据库
- (void)createTablesNeeded;

// 配置id 埋点数据上传参数
+ (NSString *)trackGetUserID;

// 配置URL 上传服务器的地址
+ (NSString *)trackServiceURL;

// 配置黑名单
+ (NSArray *)blackListArray;
@end

NS_ASSUME_NONNULL_END

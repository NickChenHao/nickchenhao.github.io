//
//  UITableView+CollectEvent.m
//  Nick
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "UITableView+CollectEvent.h"

@implementation UITableView (CollectEvent)
+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        [self sel_exchangeFirstSel:@selector(setDelegate:) secondSel:@selector(ch_setDelegate:)];
    });
}

- (void)ch_setDelegate:(id<UITableViewDelegate>)delegate {
    if (![self isContainSel:GET_CLASS_CUSTOM_SEL(@selector(tableView:didSelectRowAtIndexPath:),[delegate class]) inClass:[delegate class]]) {
        [self swizzling_tableViewDidSelectRowAtIndexPathInClass:delegate];
    }
    [self ch_setDelegate:delegate];
}

- (void)swizzling_tableViewDidSelectRowAtIndexPathInClass:(id)object {
    SEL sel = @selector(tableView:didSelectRowAtIndexPath:);

    
    // 为每个含tableView的控件 增加swizzle delegate method
    [self class_addMethod:[object class]
                 selector:GET_CLASS_CUSTOM_SEL(sel,[object class])
                      imp:method_getImplementation(class_getInstanceMethod([self class],@selector(ch_imp_tableView:didSelectRowAtIndexPath:)))
                    types:"v@:@@"];
    
    // 检查页面是否已经实现了origin delegate method  如果没有手动加一个
    if (![self isContainSel:sel inClass:[object class] ]) {
        [self class_addMethod:[object class]
                     selector:sel
                          imp:nil
                        types:"v@:@@"];
    }
    
    // 将swizzle delegate method 和 origin delegate method 交换
    [self sel_exchangeClass:[object class]
                   FirstSel:sel
                  secondSel:GET_CLASS_CUSTOM_SEL(sel,[object class])];
}

/**
 swizzle method IMP
 */
- (void)ch_imp_tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    SEL sel = GET_CLASS_CUSTOM_SEL(@selector(tableView:didSelectRowAtIndexPath:),[self class]);
    if ([self respondsToSelector:sel]) {
        IMP imp = [self methodForSelector:sel];
        void (*func)(id, SEL,id,id) = (void *)imp;
        func(self, sel,tableView,indexPath);
    }


    if (kShouldTrackClass([self class])) {
        // 控制器名称
        NSString *vcname = NSStringFromClass([self class]);

        // 创建模型
        LogDTO *model = [LogDTO new];
        model.vc_id = vcname;
        model.logType = LogTypeVCRemainTime;
        model.remainTime = [[NSDate date] timeIntervalSince1970] * 1000;
        model.functionName = [NSString stringWithFormat:@"tableView:didSelectRowAtIndexPath: - %ld:%ld",indexPath.section,indexPath.row];

        DLog(@"%@",model.functionName);
        // 插入数据库
        [[LogDAO sharedInstance] insertLogDTO:@[model]];
    }
}



@end

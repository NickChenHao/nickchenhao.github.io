//
//  UIViewController+CollectEvent.m
//  Nick
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "UIViewController+CollectEvent.h"

@implementation UIViewController (CollectEvent)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 替换方法
        [self sel_exchangeFirstSel:@selector(viewDidAppear:) secondSel:@selector(ch_viewDidAppear:)];
        [self sel_exchangeFirstSel:@selector(viewDidDisappear:) secondSel:@selector(ch_viewDidDisappear:)];

    });
}


//新的viewDidAppear方法
- (void)ch_viewDidAppear:(BOOL)animated {

    // 保存时间
    NSTimeInterval remainTime = [[NSDate date] timeIntervalSince1970] * 1000;
    [[NSUserDefaults standardUserDefaults] setObject:@(remainTime) forKey:NSStringFromClass([self class])];
    [[NSUserDefaults standardUserDefaults] synchronize];

    [self ch_viewDidAppear:animated];
}

//新的viewDidDisappear方法
- (void)ch_viewDidDisappear:(BOOL)animated {

    if (kShouldTrackClass([self class])) {
        [self insertLog];
    }

    [self ch_viewDidAppear:animated];
}

- (void)insertLog{
    // 控制器名称
    NSString *vcname = NSStringFromClass([self class]);

    // 创建模型
    LogDTO *model = [LogDTO new];
    model.vc_id = ISEMPTY(self.title)?vcname:self.title;
    model.logType = LogTypeVCRemainTime;
    model.remainTime = [[NSDate date] timeIntervalSince1970] * 1000;
    model.functionName = @"viewDidDisAppear";

    NSTimeInterval newTime = [[NSDate date] timeIntervalSince1970] * 1000;
    NSTimeInterval oldTime = [[[NSUserDefaults standardUserDefaults] objectForKey:vcname] doubleValue];
    model.remainTime = [self getRemainTimeWithNewTime:newTime OldTime:oldTime];

    // 插入数据库
    [[LogDAO sharedInstance] insertLogDTO:@[model]];
}

#pragma mark - 获取相隔时间
- (NSTimeInterval)getRemainTimeWithNewTime:(NSTimeInterval)newTime OldTime:(NSTimeInterval)oldTime{
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyyy-MM-dd-HH:mm:ss"];//@"yyyy-MM-dd-HHmmss"

    NSDate* date = [NSDate dateWithTimeIntervalSince1970:oldTime/1000];
    NSString *dateString = [formatter stringFromDate:date];

    NSDate *date2 = [NSDate dateWithTimeIntervalSince1970:newTime/1000];
    NSString *dateString2 = [formatter stringFromDate:date2];

    NSTimeInterval seconds = [date2 timeIntervalSinceDate:date];

    return seconds;
}



@end

//
//  NSObject+RuntimeMethodHelper.h
//  Nick
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>

@interface NSObject (RuntimeMethodHelper)

- (BOOL)class_addMethod:(Class)Class selector:(SEL)selector imp:(IMP)imp types:(const char *)types;

- (void)sel_exchangeFirstSel:(SEL)sel1 secondSel:(SEL)sel2;

- (void)sel_exchangeClass:(Class)Class FirstSel:(SEL)sel1 secondSel:(SEL)sel2;

- (IMP)method_getImplementation:(Method)method;

- (Method)class_getInstanceMethod:(Class)Class selector:(SEL)selector;

- (BOOL)isContainSel:(SEL)sel inClass:(Class)Class;

- (void)log_class_copyMethodList:(Class)Class;
@end

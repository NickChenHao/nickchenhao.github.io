//
//  NSNotificationCenter+CollectEvent.h
//  test
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019 Nick. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSNotificationCenter (CollectEvent)


@end

NS_ASSUME_NONNULL_END

//
//  UIControl+CollectEvent.h
//  Nick
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIControl (CollectEvent)

@end

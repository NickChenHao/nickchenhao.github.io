//
//  UIControl+CollectEvent.m
//  Nick
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019年 Nick. All rights reserved.
//

#import "UIControl+CollectEvent.h"


static NSString * const vCName = @"viewControllerName"; // 控制器名称
static NSString * const buttonName = @"buttonName";     // 按钮名称
static NSString * const buttonCount = @"buttonCount";   // 按钮点击次数

@implementation UIControl (CollectEvent)
+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        //创建新的sendAction:to:forEvent:方法
        [self sel_exchangeFirstSel:@selector(sendAction:to:forEvent:) secondSel:@selector(ch_sendAction:to:forEvent:)];
    });

}


- (void)ch_sendAction:(SEL)action to:(nullable id)target forEvent:(nullable UIEvent *)event {

    if (kShouldTrackClass([target class])) {
        [self fmdbWithAction:action to:target forEvent:event];
    }

    [self ch_sendAction:action to:target forEvent:event];
}

#pragma mark - FMDB记录
- (void)fmdbWithAction:(SEL)action to:(nullable id)target forEvent:(nullable UIEvent *)event{
    // 检测按钮名称 点击次数 监听者
    if ([self isKindOfClass:[UIButton class]]) {
        // 按钮名称
        NSString *btnname = ((UIButton *)self).titleLabel.text.length==0?NSStringFromClass([UIButton class]):((UIButton *)self).titleLabel.text;
        // 控制器名称
        NSString *vcname = NSStringFromClass([target class]);

        // 创建模型
        LogDTO *model = [LogDTO new];
        model.vc_id = vcname;
        model.btn_id = btnname;
        model.logType = LogTypeButtonClick;
        model.functionName = NSStringFromSelector(action);
        model.lastTime = [[NSDate date] timeIntervalSince1970] * 1000;

        // 若存在 次数加1
        if ([[LogDAO sharedInstance] isExsitWithDTO:@[model]]) {
            model.num += [[LogDAO sharedInstance] getBtnClickNumWithLogDTO:model];
        }

        // 插入数据库
        [[LogDAO sharedInstance] insertLogDTO:@[model]];

        DLog(@"Log信息：{\n 按钮名称:%@ \n 点击次数:%zd \n 最后时间:%f \n 所属类:%@ \n}",
              model.btn_id,
              [[LogDAO sharedInstance] getBtnClickNumWithLogDTO:model],
              model.lastTime,
              NSStringFromClass([target class]));
    }
}



@end

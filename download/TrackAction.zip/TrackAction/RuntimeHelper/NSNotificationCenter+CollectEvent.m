//
//  NSNotificationCenter+CollectEvent.m
//  test
//
//  Created by nick on 2019/6/24.
//  Copyright © 2019 Nick. All rights reserved.
//

#import "NSNotificationCenter+CollectEvent.h"

@implementation NSNotificationCenter (CollectEvent)

+ (void)load {

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        [self sel_exchangeFirstSel:@selector(postNotificationName:object:userInfo:) secondSel:@selector(ch_postNotificationName:object:userInfo:)];
    });

}


- (void)ch_postNotificationName:(NSString *)name
                         object:(nullable id)object
                       userInfo:(nullable NSDictionary *)info {

    if ([name isEqualToString:UIApplicationDidBecomeActiveNotification]) {
        //app从后台被激活时
        [self processEventTrackAtLaunch];
    }
    else if ([name isEqualToString:UIApplicationWillResignActiveNotification] ||
             [name isEqualToString:UIApplicationWillTerminateNotification]) {
        //app进入后台时
        [self processEventTrackAtTerminated];
    }

    [self ch_postNotificationName:name object:object userInfo:info];
}

#pragma mark - app启动或者从后台被激活时

- (void)processEventTrackAtLaunch {

    // 创建模型
    LogDTO *model = [LogDTO new];
    model.logType = LogTypeLaunch;
    // 插入数据库
    [[LogDAO sharedInstance] insertLogDTO:@[model]];

    DLog(@"APP - Launch");

}

- (void)processEventTrackAtTerminated {

    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [queue setMaxConcurrentOperationCount:5];

    NSBlockOperation *termminateOpe = [NSBlockOperation blockOperationWithBlock:^{

    }];

    // 创建模型
    LogDTO *model = [LogDTO new];
    model.logType = LogTypeTerminated;
    // 插入数据库
    [[LogDAO sharedInstance] insertLogDTO:@[model]];

    DLog(@"APP - Terminated");

    NSBlockOperation *flushOpe = [NSBlockOperation blockOperationWithBlock:^{

        //上传服务器
        [[LogDAO sharedInstance] uploadTrackDataToServerWithCompletion:^(BOOL success, NSError * _Nonnull error) {
            //成功后删除表数据
            [[LogDAO sharedInstance] deleteLogTable];
        }];

    }];

    [flushOpe addDependency:termminateOpe];

    [queue addOperations:@[termminateOpe, flushOpe] waitUntilFinished:NO];
}

@end

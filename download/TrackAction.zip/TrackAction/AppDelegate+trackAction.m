//
//  AppDelegate+trackAction.m
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//

#import "AppDelegate+trackAction.h"

@implementation AppDelegate (trackAction)

- (void)createTablesNeeded{
    // 创建数据库
    [DAO createTablesNeeded];

    //开启后端云SDK
    [Bmob registerWithAppKey:BMOBAPPKEY];

    //获取服务器数据
    [[LogDAO sharedInstance] getTrackDataFromServer];

}

+ (NSString *)trackGetUserID{
    return @"";
}

+ (NSString *)trackServiceURL{
    return @"";
}
@end

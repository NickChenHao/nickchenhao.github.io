//
//  TrackConstant.h
//  TheOnlineTax
//
//  Created by nick on 2019/7/3.
//  Copyright © 2019 Aisino. All rights reserved.
//

#ifndef TrackConstant_h
#define TrackConstant_h

/** 应用名称 */
#define kDisplayName [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"]
/** 应用版本号 */
#define kVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
/** 空字典判断 */
#define KDictionaryIsEmpty(dic) (dic == nil || [dic isKindOfClass:[NSNull class]] || dic.allKeys.count == 0)
/** 空字符串判断 */
#define KStringIsEmpty(str) (![str isKindOfClass:[NSString class]] || !str.length || str == nil || [str isEqualToString:@"(null)"])? @"" : str
/** 判断空值 */
#define ISNULL(_VAR) (_VAR == nil || [_VAR isKindOfClass:[NSNull class]])
#define ISEMPTY(_STR) (ISNULL(_STR) || [_STR isKindOfClass:[NSString class]] && !((NSString*)_STR).length)

/** return sel */
#define GET_CLASS_CUSTOM_SEL(sel,class)  NSSelectorFromString([NSString stringWithFormat:@"%@_%@",NSStringFromClass(class),NSStringFromSelector(sel)])

/** 黑名单 不需要追踪的控制器 */
#import <UIKit/UIKit.h>
UIKIT_STATIC_INLINE BOOL kShouldTrackClass(Class aClass){
    static NSSet *blacklistedClasses = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *path = [[NSBundle mainBundle] pathForResource:@"BlackListed" ofType:@"plist"];
        NSArray *blacklistedClassNames = [NSArray arrayWithContentsOfFile:path];;
        NSMutableSet *transformedClasses = [NSMutableSet setWithCapacity:blacklistedClassNames.count];
        for (NSString *className in blacklistedClassNames) {
            [transformedClasses addObject:NSClassFromString(className)];
        }
        blacklistedClasses = [transformedClasses copy];
    });
    return ![blacklistedClasses containsObject:aClass];
}


/** 打印信息 */
#ifdef DEBUG
#define DLog(format, ...) printf("\n[%s] %s [第%d行] %s\n", __TIME__, __FUNCTION__, __LINE__, [[NSString stringWithFormat:format, ## __VA_ARGS__] UTF8String]);
#else
#define DLog(...)
#endif

/** 强弱引用 */
#ifndef    weakify
#if __has_feature(objc_arc)
#define weakify( x )    autoreleasepool{} __weak __typeof__(x) __weak_##x##__ = x;
#else    // #if __has_feature(objc_arc)
#define weakify( x )    autoreleasepool{} __block __typeof__(x) __block_##x##__ = x;
#endif    // #if __has_feature(objc_arc)
#endif    // #ifndef    weakify

#ifndef    normalize
#if __has_feature(objc_arc)
#define normalize( x )    try{} @finally{} __typeof__(x) x = __weak_##x##__;
#else    // #if __has_feature(objc_arc)
#define normalize( x )    try{} @finally{} __typeof__(x) x = __block_##x##__;
#endif    // #if __has_feature(objc_arc)
#endif    // #ifndef    @normalize

#endif /* TrackConstant_h */

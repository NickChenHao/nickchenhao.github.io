//
//  TrackAction.h
//  Nick
//
//  Created by nick on 2019/6/25.
//  Copyright © 2019 Nick. All rights reserved.
//  无埋点数据统计方案


/*
  【 使用说明 】
 1.依赖 pod 'MJExtension' 和 pod 'AFNetworking'
 2.需在pch文件中引用  #import "TrackAction.h"
 3.需在AppDelegate.m文件中实现分类方法
   a.createTablesNeeded 创建数据库(必须)
   b.trackGetUserID     配置userID（非必须）
   c.trackServiceURL    配置上传服务器的地址
 4.可添加不需要统计的控制器在BlackListed.plist
 */

#ifndef TrackAction_h
#define TrackAction_h


// 后端云SDK appKey
#define BMOBAPPKEY @"526ace8a89cbf047f72d57e5bb8684d5"

/** 后端云SDK */
#import <BmobSDK/Bmob.h>



#import "TrackConstant.h"
#import "AppDelegate+trackAction.h"
#import "RuntimeHelper.h"
#import "TrackActionServiceManager.h"
#import "DeviceAndSystemTool.h"
#import "LogDAO.h"

#endif /* TrackAction_h */
